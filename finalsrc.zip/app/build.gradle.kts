plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.afklauncher"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.afklauncher"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "META-INF/INDEX.LIST"
            excludes += "META-INF/io.netty.versions.properties"
        }
    }
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.3")

    // Compose
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.navigation:navigation-compose:2.8.5")

    // AndroidX
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-service:2.8.7")

    // Room
    val roomVersion = "2.6.1"
    implementation("androidx.room:room-runtime:$roomVersion")
    implementation("androidx.room:room-ktx:$roomVersion")
    ksp("androidx.room:room-compiler:$roomVersion")

    // DataStore
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // Security
    implementation("androidx.security:security-crypto:1.1.0-alpha06")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // Networking (Microsoft OAuth)
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.google.code.gson:gson:2.11.0")

    // MCProtocolLib - Minecraft Java 1.21.7 (locked; see MinecraftVersions.kt for the
    // full table of what other MCProtocolLib releases support if this ever needs to move)
    //
    // NOTE: 1.21.4-1 is NOT resolvable from the OpenCollab Maven repo (verified directly
    // against https://repo.opencollab.dev/maven-releases/ - it 404s despite the GitHub
    // tag existing, which is not the same thing as an artifact having actually been
    // published). 1.21.7-1 is the real current latest release. MCProtocolLib has not
    // been updated since, so it cannot connect to Minecraft 1.21.8+ or any 26.x server -
    // there is currently no workaround for that short of GeyserMC publishing a new build.
    //
    // IMPORTANT: exclude org.cloudburstmc.math:api here, NOT :immutable.
    // immutable's own pom.xml (github.com/CloudburstMC/math) builds it with the Maven
    // Shade plugin and no relocation/exclusion config, which bundles a full unrelocated
    // copy of every api class directly into immutable-2.0.jar. immutable is therefore a
    // complete, self-contained artifact - it has the interfaces AND the actual
    // ServiceLoader-registered Vector3d/Vector3f implementation. Depending on both api
    // and immutable at once (MCProtocolLib's own gradle bundle does exactly this) means
    // every one of those shaded classes exists twice on the classpath - harmless on a
    // plain JVM build (first one found on the classpath silently wins), but a hard
    // "Duplicate class" failure under Android's stricter dexing checks. Excluding
    // immutable instead (as a previous version of this file did) "fixes" the duplicate-
    // class error but leaves only the interface-only api jar - no implementation for
    // MathImplementationLoader to find, which compiles fine and then crashes at runtime
    // the instant any packet constructs a Vector3d (e.g. the first position sync after
    // spawning). Excluding api instead avoids both problems at once.
    implementation("org.geysermc.mcprotocollib:protocol:1.21.7-1") {
        exclude(group = "org.cloudburstmc.math", module = "api")
    }

    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}



