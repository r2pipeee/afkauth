package com.afklauncher.protocol

/**
 * Reference table of Minecraft Java versions supported by MCProtocolLib
 * (https://github.com/GeyserMC/MCProtocolLib), the library this app uses to talk to
 * Minecraft servers.
 *
 * IMPORTANT: MCProtocolLib is compiled against exactly ONE Minecraft protocol per
 * released artifact - it is not a multi-version library like a proxy (e.g. ViaVersion).
 * Only the Minecraft version(s) whose [Entry.protocolLibArtifact] matches
 * [ACTIVE_PROTOCOL_LIB_ARTIFACT] (the dependency actually pinned in app/build.gradle.kts)
 * will be able to connect from this build. Everything else in the table is here so:
 *   1) instances can be labeled with the version their server actually runs, and
 *   2) upgrading later is a one-line dependency bump + a table edit, not a guessing game.
 *
 * Source: GeyserMC/MCProtocolLib release notes (github.com/GeyserMC/MCProtocolLib/releases),
 * cross-checked against what actually resolves from https://repo.opencollab.dev/maven-releases/
 * (a GitHub release tag existing is not proof the artifact was published there - see the
 * 1.21.4-1 entry below). Re-check both before bumping ACTIVE_PROTOCOL_LIB_ARTIFACT.
 *
 * Hard ceiling as of this writing: 1.21.7-1 is the newest MCProtocolLib release that
 * exists, and Minecraft has moved past it - 1.21.8 through 1.21.11 shipped after, and
 * as of mid-2026 the game switched to year-based versioning entirely (26.1 "Tiny
 * Takeover", 26.2 "Chaos Cubed", ...). This app cannot connect to any server running
 * 1.21.8 or newer, including all 26.x servers, until GeyserMC publishes a new release -
 * there is no code-level workaround for a protocol version the library doesn't implement.
 */
object MinecraftVersions {

    data class Entry(
        val minecraftVersion: String,
        val protocolLibArtifact: String
    ) {
        val isSupportedByCurrentBuild: Boolean
            get() = protocolLibArtifact == ACTIVE_PROTOCOL_LIB_ARTIFACT
    }

    /**
     * The MCProtocolLib artifact currently pinned in app/build.gradle.kts
     * (implementation("org.geysermc.mcprotocollib:protocol:...")).
     * Update this whenever that dependency line changes.
     */
    const val ACTIVE_PROTOCOL_LIB_ARTIFACT = "1.21.7-1"

    /**
     * Every Minecraft version this table knows about, newest first, grouped by the
     * MCProtocolLib artifact that implements its protocol.
     */
    val ALL: List<Entry> = listOf(
        // 1.21.5, 1.21.6, and 1.21.7 are each their own MCProtocolLib release (verified
        // against MinecraftCodec.CODEC's declared minecraftVersion at each tag - unlike
        // e.g. 1.21/1.21.1 or 1.20.5/1.20.6, these three do NOT share one artifact).
        Entry("1.21.7", "1.21.7-1"),
        Entry("1.21.6", "1.21.6-1"),
        Entry("1.21.5", "1.21.5-1"),
        // 1.21.4-1 exists as a GitHub release tag but is NOT currently resolvable from
        // the OpenCollab Maven repo (confirmed: 404 on maven-releases and
        // maven-snapshots). Left in the table for labeling/history only - do not point
        // ACTIVE_PROTOCOL_LIB_ARTIFACT at it, the build will fail to resolve.
        Entry("1.21.4", "1.21.4-1"),
        Entry("1.21.3", "1.21.2-1"),
        Entry("1.21.2", "1.21.2-1"),
        Entry("1.21.1", "1.21-1"),
        Entry("1.21", "1.21-1"),
        Entry("1.20.6", "1.20.6-1"),
        Entry("1.20.5", "1.20.6-1"),
        Entry("1.20.4", "1.20.4-1"),
        Entry("1.20.3", "1.20.4-1"),
        Entry("1.20.2", "1.20.2-1"),
        Entry("1.20.1", "1.20-1"),
        Entry("1.20", "1.20-1"),
        Entry("1.19.4", "1.19.4-1"),
        Entry("1.19.2", "1.19.2-1"),
        Entry("1.19.1", "1.19.2-1"),
        Entry("1.19", "1.19-1"),
        Entry("1.18.2", "1.18.2-1")
    )

    /** Versions that will actually connect with the MCProtocolLib build currently pinned. */
    val supported: List<Entry> get() = ALL.filter { it.isSupportedByCurrentBuild }

    /** Sensible default to preselect in the create-instance version picker. */
    val defaultVersion: String get() = supported.firstOrNull()?.minecraftVersion ?: ALL.first().minecraftVersion

    fun isSupportedByCurrentBuild(minecraftVersion: String): Boolean =
        ALL.find { it.minecraftVersion == minecraftVersion }?.isSupportedByCurrentBuild ?: false
}
