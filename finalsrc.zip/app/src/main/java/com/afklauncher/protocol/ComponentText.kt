package com.afklauncher.protocol

import net.kyori.adventure.text.Component
import net.kyori.adventure.text.TextComponent

/**
 * Minimal Adventure Component -> plain text flattening.
 *
 * MCProtocolLib's own build.gradle.kts only pulls in `adventure-text-serializer-gson`
 * and `adventure-text-serializer-json-legacy-impl` (see its `bundles.adventure` entry) -
 * NOT `adventure-text-serializer-plain`. That serializer is therefore not on this app's
 * classpath, and the previous code's
 * `import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer`
 * failed to resolve at compile time.
 *
 * Rather than pull in a whole extra dependency for what amounts to displaying chat/
 * system messages as plain text, this walks the component tree directly: every
 * TextComponent's own content, plus its children's, concatenated in order. This
 * covers ordinary chat, kick reasons, and MOTD-style messages. It does not resolve
 * TranslatableComponent keys (e.g. "multiplayer.player.joined") to localized text,
 * since doing that properly needs the client-side language file MCProtocolLib
 * doesn't ship - those will just be skipped rather than shown incorrectly.
 */
fun Component.toPlainText(): String {
    val builder = StringBuilder()

    fun visit(component: Component) {
        if (component is TextComponent) {
            builder.append(component.content())
        }
        component.children().forEach { visit(it) }
    }

    visit(this)
    return builder.toString()
}
