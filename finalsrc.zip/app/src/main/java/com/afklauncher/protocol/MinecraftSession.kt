package com.afklauncher.protocol

import android.util.Log
import com.afklauncher.auth.AuthException
import com.afklauncher.auth.MicrosoftAuthService
import com.afklauncher.data.db.AccountEntity
import com.afklauncher.data.db.InstanceEntity
import com.afklauncher.data.repository.AccountRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.geysermc.mcprotocollib.auth.GameProfile
import org.geysermc.mcprotocollib.auth.SessionService
import org.geysermc.mcprotocollib.network.ClientSession
import org.geysermc.mcprotocollib.network.Session
import org.geysermc.mcprotocollib.network.event.session.DisconnectedEvent
import org.geysermc.mcprotocollib.network.event.session.SessionAdapter
import org.geysermc.mcprotocollib.network.factory.ClientNetworkSessionFactory
import org.geysermc.mcprotocollib.network.packet.Packet
import org.geysermc.mcprotocollib.protocol.MinecraftConstants
import org.geysermc.mcprotocollib.protocol.MinecraftProtocol
import org.geysermc.mcprotocollib.protocol.data.game.entity.player.HandPreference
import org.geysermc.mcprotocollib.protocol.data.game.entity.player.PositionElement
import org.geysermc.mcprotocollib.protocol.data.game.setting.ChatVisibility
import org.geysermc.mcprotocollib.protocol.data.game.setting.ParticleStatus
import org.geysermc.mcprotocollib.protocol.data.game.setting.SkinPart
import org.geysermc.mcprotocollib.protocol.packet.common.clientbound.ClientboundKeepAlivePacket
import org.geysermc.mcprotocollib.protocol.packet.common.serverbound.ServerboundClientInformationPacket
import org.geysermc.mcprotocollib.protocol.packet.configuration.clientbound.ClientboundSelectKnownPacks
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.ClientboundLoginPacket
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.ClientboundPlayerChatPacket
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.ClientboundSystemChatPacket
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.entity.ClientboundSetEntityMotionPacket
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.entity.player.ClientboundPlayerPositionPacket
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.entity.player.ClientboundSetExperiencePacket
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.entity.player.ClientboundSetHealthPacket
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.inventory.ClientboundContainerSetContentPacket
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.level.ClientboundChunkBatchFinishedPacket
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.level.ClientboundChunkBatchStartPacket
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.level.ClientboundLevelChunkWithLightPacket
import org.geysermc.mcprotocollib.protocol.packet.ingame.serverbound.ServerboundChatPacket
import org.geysermc.mcprotocollib.protocol.packet.ingame.serverbound.ServerboundClientTickEndPacket
import org.geysermc.mcprotocollib.protocol.packet.ingame.serverbound.ServerboundPlayerLoadedPacket
import org.geysermc.mcprotocollib.protocol.packet.ingame.serverbound.level.ServerboundAcceptTeleportationPacket
import org.geysermc.mcprotocollib.protocol.packet.ingame.serverbound.level.ServerboundChunkBatchReceivedPacket
import org.geysermc.mcprotocollib.protocol.packet.ingame.serverbound.level.ServerboundPlayerInputPacket
import org.geysermc.mcprotocollib.protocol.packet.ingame.serverbound.player.ServerboundMovePlayerPosRotPacket
import java.time.Instant
import java.util.BitSet
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Drives one Minecraft connection: login, keepalive, chat, a minimal but physically
 * consistent movement/gravity simulation, and AFK behaviors.
 *
 * A few things this class deliberately does that a naive bot skips, because servers
 * (and their anti-cheat plugins) expect every "vanilla-shaped" client to do them:
 *  - Reply to every teleport (ClientboundPlayerPositionPacket) with
 *    ServerboundAcceptTeleportationPacket using the same id. Skipping this is one of
 *    the fastest ways to get flagged as a modified/non-vanilla client.
 *  - Apply real vertical gravity after jumps and after server-sent knockback
 *    (ClientboundSetEntityMotionPacket) instead of snapping to a height and staying
 *    there, which reads as a NoFall/flight hack to most anti-cheats.
 *  - Acknowledge chunk batches and send ServerboundPlayerLoadedPacket like a real
 *    client performing the post-1.20.5 load handshake, instead of going silent after
 *    spawning in.
 *  - Send ServerboundClientInformationPacket (render distance, locale, etc.) during
 *    the configuration phase like every real client does. MCProtocolLib's built-in
 *    ClientListener does NOT send this automatically - skipping it entirely is both
 *    a deviation from vanilla client behavior and the reason a server might only
 *    stream a small/default chunk radius around the bot instead of its actual max
 *    view distance.
 *  - Report movement intent via ServerboundPlayerInputPacket (forward/backward/left/
 *    right/jump/sneak/sprint as one consolidated per-tick packet) instead of the older
 *    entity-action packet, which doesn't even have sneak values in this protocol
 *    version anymore. This is sent every active tick, matching real client cadence -
 *    it is not "spam" for this specific packet the way repeatedly sending a one-shot
 *    action packet would be.
 *  - NOT double-acknowledge keepalives: MCProtocolLib's built-in ClientListener
 *    already auto-replies to every ClientboundKeepAlivePacket (see
 *    MinecraftConstants.AUTOMATIC_KEEP_ALIVE_MANAGEMENT, on by default). This class
 *    only reads keepalives for ping tracking and must not also reply to them itself,
 *    or the server sees two acks for one keepalive - not something a real client does.
 *
 * What this class still can NOT do: real block collision. It has no voxel/terrain
 * data (only a coarse per-chunk marker for the minimap), so "ground" is approximated
 * as the last server-confirmed or jump-origin Y rather than the true block height.
 * That's fine for flat AFK platforms/farms but won't behave correctly on uneven
 * terrain - a real collision system would need full chunk section + block palette
 * parsing, which is a much larger feature than this fix.
 */
class MinecraftSession(
    private val scope: CoroutineScope,
    private val instance: InstanceEntity,
    private val account: AccountEntity,
    private val authService: MicrosoftAuthService,
    private val accountRepository: AccountRepository,
    private val onSessionEnded: () -> Unit
) {
    private companion object {
        const val TICK_MS = 50L
        const val GRAVITY = 0.08
        const val VERTICAL_DRAG = 0.98
        const val GROUND_FRICTION = 0.91
        const val JUMP_VELOCITY = 0.42
        const val MIN_VELOCITY = 0.005
        const val PLAYER_LOADED_FALLBACK_MS = 5000L
        // Maximum view distance a vanilla client can request (the options menu caps
        // at 32). The server always clamps to min(this, its own configured max), so
        // requesting the ceiling guarantees we get however many chunks around the
        // bot the server is willing to send - satisfying "load the server's max
        // chunk limit" without needing to know that server's actual configured limit.
        const val RENDER_DISTANCE = 32
    }

    private val tag = "MinecraftSession-${instance.id}"
    private var session: Session? = null
    private var entityId: Int = 0
    private var afkJob: Job? = null
    private var movementJob: Job? = null
    private var reconnectJob: Job? = null
    private var lastKeepAliveTime = 0L

    // Mutable copies of the account's tokens. Microsoft rotates the refresh token on every
    // use, so these must be updated (and persisted, see connect()) after every successful
    // refresh - otherwise the *next* reconnect attempt in this same session would still
    // hand Microsoft the now-invalidated refresh token and fail.
    private var currentAccessToken = account.accessToken
    private var currentRefreshToken = account.refreshToken

    // Simple physics state. velocityX/Z carry server-applied knockback until it decays;
    // velocityY carries both knockback and normal jump/fall motion. groundY is the best
    // known "floor" - updated on every authoritative teleport and whenever we leave the
    // ground under our own control (see the class doc for why this is an approximation).
    private var velocityX = 0.0
    private var velocityY = 0.0
    private var velocityZ = 0.0
    // Matches PlayerState's default y (see ProtocolModels.kt) so a jump() called
    // before the server's first position packet arrives doesn't think "ground" is
    // 64 blocks below where we actually spawn.
    private var groundY = 64.0
    private var hasSentPlayerLoaded = false
    private var hasSentClientInformation = false

    private val _state = MutableStateFlow(buildInitialState())
    val state: StateFlow<SessionState> = _state.asStateFlow()

    private var movementInput = MovementInput()
    private var playerState = PlayerState()
    private val chatHistory = mutableListOf<ChatMessage>()
    private val inventorySlots = mutableListOf<InventorySlot>()
    private val chunkBlocks = mutableListOf<ChunkBlock>()
    private val afkSettings = AfkSettings.fromInstance(instance)

    fun connect() {
        if (_state.value.status == ConnectionStatus.CONNECTING ||
            _state.value.status == ConnectionStatus.ONLINE
        ) return

        scope.launch {
            try {
                updateStatus(ConnectionStatus.CONNECTING)

                val authResult = try {
                    authService.refreshAuth(currentRefreshToken)
                } catch (e: AuthException) {
                    // Previously this silently fell back to the old (likely expired)
                    // access token, which just traded a clear error now for a confusing
                    // "connection failed" later. Surface it and stop instead of hammering
                    // Microsoft's servers with a dead refresh token on every auto-reconnect.
                    Log.e(tag, "Microsoft token refresh failed for ${account.username}", e)
                    updateStatus(
                        ConnectionStatus.ERROR,
                        "Microsoft sign-in expired for ${account.username}. Remove and re-add the account."
                    )
                    onSessionEnded()
                    return@launch
                }

                // Microsoft rotates the refresh token on every use - persist the new
                // tokens immediately so this session's next reconnect, and any future
                // session for this account, doesn't try to reuse an invalidated token.
                currentAccessToken = authResult.accessToken
                currentRefreshToken = authResult.refreshToken
                try {
                    accountRepository.updateAccount(
                        account.copy(
                            uuid = authResult.uuid,
                            username = authResult.username,
                            accessToken = authResult.accessToken,
                            refreshToken = authResult.refreshToken,
                            authDataJson = authResult.authDataJson
                        )
                    )
                } catch (e: Exception) {
                    Log.e(tag, "Failed to persist refreshed Microsoft tokens", e)
                }

                // Fresh physics/handshake state for this connection attempt.
                velocityX = 0.0
                velocityY = 0.0
                velocityZ = 0.0
                hasSentPlayerLoaded = false
                hasSentClientInformation = false

                val profile = GameProfile(authResult.uuid, authResult.username)
                val protocol = MinecraftProtocol(profile, authResult.accessToken)
                val sessionService = SessionService()

                // TcpClientSession was removed from MCProtocolLib as of 1.21.5-1; this
                // factory is the current (1.21.7-1) way to build a client session.
                val clientSession: ClientSession = ClientNetworkSessionFactory.factory()
                    .setAddress(instance.serverIP, instance.serverPort)
                    .setProtocol(protocol)
                    .create()
                clientSession.setFlag(MinecraftConstants.SESSION_SERVICE_KEY, sessionService)

                clientSession.addListener(object : SessionAdapter() {
                    override fun packetReceived(session: Session, packet: Packet) {
                        handlePacket(packet)
                    }

                    override fun disconnected(event: DisconnectedEvent) {
                        Log.d(tag, "Disconnected: ${event.reason}")
                        scope.launch {
                            handleDisconnect(event.reason?.toPlainText())
                        }
                    }
                })

                session = clientSession
                clientSession.connect()

                updateStatus(ConnectionStatus.ONLINE)
                startAfkController()
                startMovementLoop()
            } catch (e: Exception) {
                Log.e(tag, "Connection failed", e)
                updateStatus(ConnectionStatus.ERROR, e.message)
                scheduleReconnect()
            }
        }
    }

    fun disconnect() {
        reconnectJob?.cancel()
        afkJob?.cancel()
        movementJob?.cancel()
        session?.disconnect("Disconnected by user")
        session = null
        updateStatus(ConnectionStatus.OFFLINE)
        onSessionEnded()
    }

    fun sendChat(message: String) {
        val currentSession = session ?: return
        if (!currentSession.isConnected) return

        try {
            currentSession.send(
                ServerboundChatPacket(
                    message,
                    Instant.now().toEpochMilli(),
                    0L,
                    null,
                    0,
                    BitSet(),
                    0
                )
            )
            addChatMessage(account.username, message, isSystem = false)
        } catch (e: Exception) {
            Log.e(tag, "Failed to send chat", e)
        }
    }

    fun updateMovementInput(input: MovementInput) {
        movementInput = input
    }

    fun jump() {
        // Give the tick loop a vertical impulse instead of teleporting up once and
        // never coming back down - the old behavior left the player floating 0.42
        // blocks above the ground forever, which is a textbook NoFall/flight flag.
        if (playerState.onGround && velocityY == 0.0) {
            velocityY = JUMP_VELOCITY
            playerState = playerState.copy(onGround = false)
        }
    }

    private fun handlePacket(packet: Packet) {
        when (packet) {
            is ClientboundLoginPacket -> {
                entityId = packet.entityId
                schedulePlayerLoadedFallback()
            }

            is ClientboundSetHealthPacket -> {
                playerState = playerState.copy(
                    health = packet.health,
                    hunger = packet.food
                )
                publishState()
            }

            is ClientboundSetExperiencePacket -> {
                playerState = playerState.copy(
                    xpLevel = packet.level,
                    xpProgress = packet.experience
                )
                publishState()
            }

            is ClientboundPlayerPositionPacket -> {
                // Some fields on a teleport are absolute and some are deltas added to
                // our current position/rotation - which is which is given by
                // `relatives`. Getting this wrong causes a visible desync from what
                // the server thinks our position is, which is exactly the kind of
                // thing anti-cheat watches for.
                val relatives = packet.relatives
                val newX = if (PositionElement.X in relatives) playerState.x + packet.position.x else packet.position.x
                val newY = if (PositionElement.Y in relatives) playerState.y + packet.position.y else packet.position.y
                val newZ = if (PositionElement.Z in relatives) playerState.z + packet.position.z else packet.position.z
                val newYaw = if (PositionElement.Y_ROT in relatives) playerState.yaw + packet.yRot else packet.yRot
                val newPitch = if (PositionElement.X_ROT in relatives) playerState.pitch + packet.xRot else packet.xRot

                velocityX = 0.0
                velocityY = 0.0
                velocityZ = 0.0
                groundY = newY

                playerState = playerState.copy(
                    x = newX,
                    y = newY,
                    z = newZ,
                    yaw = newYaw,
                    pitch = newPitch,
                    onGround = true
                )
                publishState()

                // Mandatory: a client that never confirms a teleport looks desynced
                // or non-vanilla to the server and its anti-cheat.
                try {
                    session?.send(ServerboundAcceptTeleportationPacket(packet.id))
                } catch (e: Exception) {
                    Log.e(tag, "Failed to confirm teleport", e)
                }
            }

            is ClientboundSetEntityMotionPacket -> {
                // Server-applied velocity (knockback, explosions, launch pads, etc.)
                // targeting our own entity. We fold it into the same physics the
                // movement tick already integrates, so it decays and settles
                // naturally instead of being ignored (which would leave us standing
                // still through an explosion - also very flaggable) or applied as an
                // instant teleport (which looks just as wrong).
                if (packet.entityId == entityId) {
                    velocityX = packet.motionX
                    velocityY = packet.motionY
                    velocityZ = packet.motionZ
                    playerState = playerState.copy(onGround = false)
                }
            }

            is ClientboundKeepAlivePacket -> {
                // Read-only: MCProtocolLib's built-in ClientListener already sends the
                // matching ServerboundKeepAlivePacket automatically (see class doc).
                // We only use this for ping tracking - sending our own reply here would
                // double-ack every keepalive, which no real client does.
                val now = System.currentTimeMillis()
                if (lastKeepAliveTime > 0) {
                    val ping = (now - lastKeepAliveTime).toInt()
                    playerState = playerState.copy(ping = ping.coerceAtMost(9999))
                    publishState()
                }
                lastKeepAliveTime = now
            }

            is ClientboundSelectKnownPacks -> {
                // Only reachable while inbound state is CONFIGURATION (packet IDs are
                // state-scoped, so receiving this at all proves we're there), which
                // makes it a safe, race-free trigger for sending our own
                // ClientInformation - unlike trying to time it off a shared listener
                // callback where ordering against MCProtocolLib's own ClientListener
                // isn't guaranteed.
                sendClientInformationOnce()
            }

            is ClientboundChunkBatchStartPacket -> {
                // No-op: the server is about to stream a batch of chunk packets.
                // Handled for completeness of the modern (1.20.5+) load handshake.
            }

            is ClientboundChunkBatchFinishedPacket -> {
                // Real clients ack how many chunks they actually processed; echoing
                // the reported batch size back is the simplest correct answer here.
                try {
                    session?.send(
                        ServerboundChunkBatchReceivedPacket(packet.batchSize.toFloat().coerceAtLeast(1f))
                    )
                } catch (e: Exception) {
                    Log.e(tag, "Failed to ack chunk batch", e)
                }
                sendPlayerLoadedOnce()
            }

            is ClientboundSystemChatPacket -> {
                addChatMessage("Server", packet.content.toPlainText(), isSystem = true)
            }

            is ClientboundPlayerChatPacket -> {
                val senderName = packet.name.toPlainText().ifBlank { "Player" }
                addChatMessage(senderName, packet.content, isSystem = false)
            }

            is ClientboundContainerSetContentPacket -> {
                if (packet.containerId == 0) {
                    inventorySlots.clear()
                    packet.items.forEachIndexed { index, item ->
                        if (item != null) {
                            inventorySlots.add(
                                InventorySlot(
                                    slot = index,
                                    // ItemStack only exposes the numeric protocol item id here -
                                    // resolving it to a friendly name (e.g. "Diamond Sword") would
                                    // require parsing the server's registry-sync data, which this
                                    // app doesn't do yet.
                                    itemName = "Item #${item.id}",
                                    count = item.amount
                                )
                            )
                        }
                    }
                    publishState()
                }
            }

            is ClientboundLevelChunkWithLightPacket -> {
                parseChunkForMinimap(packet)
            }
        }
    }

    /**
     * Sends ServerboundClientInformationPacket once per connection, requesting the
     * maximum standard render distance. Every real client sends this during the
     * configuration phase; without it the server has no client-declared view
     * distance to honor and may fall back to a small default (or, on some hardened
     * server setups, treat a client that never sends it as suspicious).
     */
    private fun sendClientInformationOnce() {
        if (hasSentClientInformation) return
        hasSentClientInformation = true
        try {
            session?.send(
                ServerboundClientInformationPacket(
                    "en_us",
                    RENDER_DISTANCE,
                    ChatVisibility.FULL,
                    true,
                    SkinPart.VALUES.toList(),
                    HandPreference.RIGHT_HAND,
                    false,
                    true,
                    ParticleStatus.ALL
                )
            )
        } catch (e: Exception) {
            Log.e(tag, "Failed to send client information", e)
        }
    }

    /**
     * Sends ServerboundPlayerLoadedPacket if it hasn't been sent yet for this
     * connection. Real clients send this once they've finished loading into the
     * world; servers/plugins that gate movement or visibility on it will otherwise
     * treat us as stuck loading forever.
     */
    private fun sendPlayerLoadedOnce() {
        if (hasSentPlayerLoaded) return
        hasSentPlayerLoaded = true
        try {
            session?.send(ServerboundPlayerLoadedPacket.INSTANCE)
        } catch (e: Exception) {
            Log.e(tag, "Failed to send player loaded", e)
        }
    }

    /**
     * Fallback in case a server never sends chunk-batch packets (older/non-vanilla
     * server software may stream chunks individually instead of batching them).
     */
    private fun schedulePlayerLoadedFallback() {
        scope.launch {
            delay(PLAYER_LOADED_FALLBACK_MS)
            sendPlayerLoadedOnce()
        }
    }

    private fun parseChunkForMinimap(packet: ClientboundLevelChunkWithLightPacket) {
        val chunkX = packet.x
        val chunkZ = packet.z
        chunkBlocks.removeAll { block ->
            block.x in (chunkX * 16) until ((chunkX + 1) * 16) &&
                block.z in (chunkZ * 16) until ((chunkZ + 1) * 16)
        }
        chunkBlocks.add(
            ChunkBlock(
                x = chunkX * 16 + 8,
                z = chunkZ * 16 + 8,
                blockId = 1,
                y = 64
            )
        )
        if (chunkBlocks.size > 512) {
            chunkBlocks.subList(0, chunkBlocks.size - 512).clear()
        }
        publishState()
    }

    private fun startMovementLoop() {
        movementJob?.cancel()
        movementJob = scope.launch {
            while (isActive && session?.isConnected == true) {
                tickMovement()
                delay(TICK_MS)
            }
        }
    }

    /**
     * One physics tick: horizontal WASD displacement plus vertical (and any pending
     * server-applied horizontal) velocity integration. Runs every tick whenever
     * there's input OR we're still airborne/decelerating from a jump or knockback,
     * so falls always finish instead of leaving the player floating.
     */
    private fun tickMovement() {
        val input = movementInput
        val hasInput = input.forward || input.backward || input.left || input.right ||
            input.jump || input.sneak || input.sprint
        val airborne = !playerState.onGround || velocityY != 0.0 || velocityX != 0.0 || velocityZ != 0.0

        if (!hasInput && !airborne) {
            // Minecraft 1.21.2+ clients send a tick-end heartbeat on ticks where they
            // have nothing else to report, so the server can still track client tick
            // timing under the newer client-authoritative movement model. Going fully
            // silent while idle (the old behavior) is not how a real client behaves.
            try {
                session?.send(ServerboundClientTickEndPacket.INSTANCE)
            } catch (_: Exception) { }
            return
        }

        val speed = if (input.sprint) 0.28 else 0.13
        var dx = 0.0
        var dz = 0.0
        val yawRad = Math.toRadians(playerState.yaw.toDouble())

        if (input.forward) {
            dx -= sin(yawRad) * speed
            dz += cos(yawRad) * speed
        }
        if (input.backward) {
            dx += sin(yawRad) * speed
            dz -= cos(yawRad) * speed
        }
        if (input.left) {
            dx -= cos(yawRad) * speed
            dz -= sin(yawRad) * speed
        }
        if (input.right) {
            dx += cos(yawRad) * speed
            dz += sin(yawRad) * speed
        }

        if (input.jump) {
            jump()
        }

        var newY = playerState.y
        var onGround = playerState.onGround

        if (!onGround || velocityY != 0.0) {
            newY += velocityY
            velocityY = (velocityY - GRAVITY) * VERTICAL_DRAG
            if (newY <= groundY && velocityY <= 0.0) {
                newY = groundY
                velocityY = 0.0
                onGround = true
            } else {
                onGround = false
            }
        }

        if (velocityX != 0.0 || velocityZ != 0.0) {
            dx += velocityX
            dz += velocityZ
            velocityX *= GROUND_FRICTION
            velocityZ *= GROUND_FRICTION
            if (abs(velocityX) < MIN_VELOCITY) velocityX = 0.0
            if (abs(velocityZ) < MIN_VELOCITY) velocityZ = 0.0
        }

        val newX = playerState.x + dx
        val newZ = playerState.z + dz

        // Real 1.21.2+ clients report forward/backward/left/right/jump/sneak/sprint as
        // one consolidated packet every tick they're moving, rather than one-off
        // "start sprinting" style events - PlayerState (the older entity-action enum)
        // doesn't even have sneak values anymore in this protocol. Sending this
        // every active tick is the correct, expected cadence, not "spam".
        try {
            session?.send(
                ServerboundPlayerInputPacket(
                    input.forward,
                    input.backward,
                    input.left,
                    input.right,
                    input.jump,
                    input.sneak,
                    input.sprint
                )
            )
        } catch (_: Exception) { }

        sendMovement(newX, newY, newZ, playerState.yaw, playerState.pitch, onGround)
        playerState = playerState.copy(x = newX, y = newY, z = newZ, onGround = onGround)
    }

    private fun sendMovement(
        x: Double,
        y: Double,
        z: Double,
        yaw: Float,
        pitch: Float,
        onGround: Boolean
    ) {
        try {
            session?.send(
                ServerboundMovePlayerPosRotPacket(onGround, false, x, y, z, yaw, pitch)
            )
        } catch (e: Exception) {
            Log.e(tag, "Movement packet failed", e)
        }
    }

    private fun startAfkController() {
        afkJob?.cancel()
        afkJob = scope.launch {
            var lastJumpTime = System.currentTimeMillis()
            var lastRotateTime = System.currentTimeMillis()

            while (isActive && session?.isConnected == true) {
                val now = System.currentTimeMillis()

                if (afkSettings.autoJump &&
                    now - lastJumpTime >= afkSettings.jumpIntervalSeconds * 1000L
                ) {
                    jump()
                    lastJumpTime = now
                }

                if (afkSettings.autoRotate &&
                    now - lastRotateTime >= 5000
                ) {
                    val newYaw = (playerState.yaw + 45f) % 360f
                    sendMovement(
                        playerState.x,
                        playerState.y,
                        playerState.z,
                        newYaw,
                        playerState.pitch,
                        playerState.onGround
                    )
                    playerState = playerState.copy(yaw = newYaw)
                    lastRotateTime = now
                }

                if (afkSettings.randomMovement && Random.nextFloat() < 0.05f) {
                    val randomYaw = Random.nextFloat() * 360f
                    val yawRad = Math.toRadians(randomYaw.toDouble())
                    val speed = 0.1
                    val newX = playerState.x - sin(yawRad) * speed
                    val newZ = playerState.z + cos(yawRad) * speed
                    sendMovement(
                        newX,
                        playerState.y,
                        newZ,
                        randomYaw,
                        playerState.pitch,
                        playerState.onGround
                    )
                    playerState = playerState.copy(x = newX, z = newZ, yaw = randomYaw)
                }

                delay(1000)
            }
        }
    }

    private fun handleDisconnect(reason: String?) {
        afkJob?.cancel()
        movementJob?.cancel()
        session = null

        if (afkSettings.autoReconnect) {
            updateStatus(ConnectionStatus.RECONNECTING, reason)
            scheduleReconnect()
        } else {
            updateStatus(ConnectionStatus.OFFLINE, reason)
            onSessionEnded()
        }
    }

    private fun scheduleReconnect() {
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            delay(afkSettings.reconnectDelaySeconds * 1000L)
            connect()
        }
    }

    private fun buildInitialState() = SessionState(
        instanceId = instance.id,
        instanceName = instance.name,
        accountName = account.username,
        serverAddress = "${instance.serverIP}:${instance.serverPort}"
    )

    private fun updateStatus(status: ConnectionStatus, error: String? = null) {
        _state.update {
            it.copy(status = status, errorMessage = error, playerState = playerState)
        }
    }

    private fun addChatMessage(sender: String, content: String, isSystem: Boolean) {
        chatHistory.add(ChatMessage(sender, content, isSystem = isSystem))
        if (chatHistory.size > 200) chatHistory.removeAt(0)
        publishState()
    }

    private fun publishState() {
        _state.update {
            it.copy(
                playerState = playerState,
                chatMessages = chatHistory.toList(),
                inventory = inventorySlots.toList(),
                nearbyBlocks = chunkBlocks.toList()
            )
        }
    }
}
