package com.afklauncher.protocol

import com.afklauncher.data.db.InstanceEntity

enum class ConnectionStatus {
    OFFLINE,
    CONNECTING,
    ONLINE,
    RECONNECTING,
    ERROR
}

data class PlayerState(
    val health: Float = 20f,
    val maxHealth: Float = 20f,
    val hunger: Int = 20,
    val armor: Int = 0,
    val xpLevel: Int = 0,
    val xpProgress: Float = 0f,
    val x: Double = 0.0,
    val y: Double = 64.0,
    val z: Double = 0.0,
    val yaw: Float = 0f,
    val pitch: Float = 0f,
    val ping: Int = 0,
    val onGround: Boolean = true
)

data class ChatMessage(
    val sender: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isSystem: Boolean = false
)

data class InventorySlot(
    val slot: Int,
    val itemName: String,
    val count: Int
)

data class ChunkBlock(
    val x: Int,
    val z: Int,
    val blockId: Int,
    val y: Int
)

data class SessionState(
    val instanceId: Long,
    val instanceName: String,
    val accountName: String,
    val serverAddress: String,
    val status: ConnectionStatus = ConnectionStatus.OFFLINE,
    val playerState: PlayerState = PlayerState(),
    val chatMessages: List<ChatMessage> = emptyList(),
    val inventory: List<InventorySlot> = emptyList(),
    val nearbyBlocks: List<ChunkBlock> = emptyList(),
    val errorMessage: String? = null
)

data class MovementInput(
    val forward: Boolean = false,
    val backward: Boolean = false,
    val left: Boolean = false,
    val right: Boolean = false,
    val jump: Boolean = false,
    val sneak: Boolean = false,
    val sprint: Boolean = false
)

data class AfkSettings(
    val autoReconnect: Boolean = true,
    val reconnectDelaySeconds: Int = 10,
    val autoJump: Boolean = false,
    val jumpIntervalSeconds: Int = 30,
    val autoRotate: Boolean = false,
    val randomMovement: Boolean = false
) {
    companion object {
        fun fromInstance(instance: InstanceEntity) = AfkSettings(
            autoReconnect = instance.autoReconnect,
            reconnectDelaySeconds = instance.reconnectDelay,
            autoJump = instance.autoJump,
            jumpIntervalSeconds = instance.jumpInterval,
            autoRotate = instance.autoRotate,
            randomMovement = instance.randomMovement
        )
    }
}



