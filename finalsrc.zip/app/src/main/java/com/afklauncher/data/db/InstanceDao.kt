package com.afklauncher.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface InstanceDao {
    @Query("SELECT * FROM instances ORDER BY name ASC")
    fun getAllInstances(): Flow<List<InstanceEntity>>

    @Query("SELECT * FROM instances WHERE id = :id")
    suspend fun getInstanceById(id: Long): InstanceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(instance: InstanceEntity): Long

    @Update
    suspend fun update(instance: InstanceEntity)

    @Delete
    suspend fun delete(instance: InstanceEntity)
}



