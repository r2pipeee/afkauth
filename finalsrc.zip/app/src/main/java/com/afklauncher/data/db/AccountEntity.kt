package com.afklauncher.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "accounts",
    indices = [Index(value = ["uuid"], unique = true)]
)
data class AccountEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val uuid: String,
    val accessToken: String,
    val refreshToken: String,
    val authDataJson: String,
    val createdDate: Long = System.currentTimeMillis()
)



