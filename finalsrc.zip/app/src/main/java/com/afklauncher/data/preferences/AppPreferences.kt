package com.afklauncher.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "afk_preferences")

class AppPreferences(private val context: Context) {

    private val chatTimestampsKey = booleanPreferencesKey("chat_timestamps")
    private val darkThemeKey = booleanPreferencesKey("dark_theme")

    val showChatTimestamps: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[chatTimestampsKey] ?: true
    }

    val darkTheme: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[darkThemeKey] ?: true
    }

    suspend fun setShowChatTimestamps(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[chatTimestampsKey] = enabled
        }
    }

    suspend fun setDarkTheme(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[darkThemeKey] = enabled
        }
    }
}



