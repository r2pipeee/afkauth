package com.afklauncher.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.afklauncher.protocol.MinecraftVersions

@Entity(
    tableName = "instances",
    foreignKeys = [
        ForeignKey(
            entity = AccountEntity::class,
            parentColumns = ["id"],
            childColumns = ["accountId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index("accountId")]
)
data class InstanceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val serverIP: String,
    val serverPort: Int = 25565,
    val accountId: Long?,
    val version: String = MinecraftVersions.defaultVersion,
    val autoReconnect: Boolean = true,
    val autoJump: Boolean = false,
    val jumpInterval: Int = 30,
    val autoRotate: Boolean = false,
    val randomMovement: Boolean = false,
    val reconnectDelay: Int = 10
)



