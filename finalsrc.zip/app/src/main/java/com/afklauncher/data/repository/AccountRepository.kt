package com.afklauncher.data.repository

import com.afklauncher.data.db.AccountDao
import com.afklauncher.data.db.AccountEntity
import kotlinx.coroutines.flow.Flow

class AccountRepository(private val accountDao: AccountDao) {

    fun getAllAccounts(): Flow<List<AccountEntity>> = accountDao.getAllAccounts()

    suspend fun getAccountById(id: Long): AccountEntity? = accountDao.getAccountById(id)

    suspend fun insertAccount(account: AccountEntity): Long = accountDao.insert(account)

    suspend fun updateAccount(account: AccountEntity) = accountDao.update(account)

    /**
     * Inserts [account] as a new row, or - if an account with the same Microsoft [uuid]
     * already exists - updates that existing row in place instead. This keeps the id
     * stable across re-logins, which matters because instances reference accounts by id
     * (see InstanceEntity.accountId): silently inserting a duplicate would leave existing
     * instances pointed at the old, now-orphaned account row.
     */
    suspend fun upsertAccount(account: AccountEntity): AccountEntity {
        val existing = accountDao.getAccountByUuid(account.uuid)
        return if (existing != null) {
            val merged = account.copy(id = existing.id, createdDate = existing.createdDate)
            accountDao.update(merged)
            merged
        } else {
            val newId = accountDao.insert(account)
            account.copy(id = newId)
        }
    }

    suspend fun deleteAccount(account: AccountEntity) = accountDao.delete(account)
}



