package com.afklauncher.data.repository

import com.afklauncher.data.db.InstanceDao
import com.afklauncher.data.db.InstanceEntity
import kotlinx.coroutines.flow.Flow

class InstanceRepository(private val instanceDao: InstanceDao) {

    fun getAllInstances(): Flow<List<InstanceEntity>> = instanceDao.getAllInstances()

    suspend fun getInstanceById(id: Long): InstanceEntity? = instanceDao.getInstanceById(id)

    suspend fun insertInstance(instance: InstanceEntity): Long = instanceDao.insert(instance)

    suspend fun updateInstance(instance: InstanceEntity) = instanceDao.update(instance)

    suspend fun deleteInstance(instance: InstanceEntity) = instanceDao.delete(instance)
}



