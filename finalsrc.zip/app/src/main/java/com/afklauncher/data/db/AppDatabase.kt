package com.afklauncher.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [AccountEntity::class, InstanceEntity::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun accountDao(): AccountDao
    abstract fun instanceDao(): InstanceDao

    companion object {
        fun create(context: Context): AppDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "afk_launcher.db"
            )
                // Schema changed (added a unique index on accounts.uuid) and this app has
                // no shipped users yet, so a real Migration isn't worth the complexity.
                // If this build has already been installed by real users, replace this
                // with a proper Migration(1, 2) instead - this wipes local accounts/instances.
                .fallbackToDestructiveMigration()
                .build()
        }
    }
}



