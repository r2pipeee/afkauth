package com.afklauncher.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.afklauncher.AFKLauncherApp
import com.afklauncher.data.db.InstanceEntity
import com.afklauncher.protocol.MinecraftVersions
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class InstanceViewModel : ViewModel() {
    private val app = AFKLauncherApp.instance
    private val instanceRepository = app.instanceRepository
    private val accountRepository = app.accountRepository

    val accounts = accountRepository.getAllAccounts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun createInstance(
        name: String,
        serverAddress: String,
        accountId: Long?,
        version: String = MinecraftVersions.defaultVersion,
        autoReconnect: Boolean = true,
        autoJump: Boolean = false,
        jumpInterval: Int = 30,
        autoRotate: Boolean = false,
        randomMovement: Boolean = false
    ) {
        viewModelScope.launch {
            val (ip, port) = parseServerAddress(serverAddress)
            instanceRepository.insertInstance(
                InstanceEntity(
                    name = name,
                    serverIP = ip,
                    serverPort = port,
                    accountId = accountId,
                    version = version,
                    autoReconnect = autoReconnect,
                    autoJump = autoJump,
                    jumpInterval = jumpInterval,
                    autoRotate = autoRotate,
                    randomMovement = randomMovement
                )
            )
        }
    }

    fun updateInstance(instance: InstanceEntity) {
        viewModelScope.launch {
            instanceRepository.updateInstance(instance)
        }
    }

    private fun parseServerAddress(address: String): Pair<String, Int> {
        val trimmed = address.trim()
        if (trimmed.contains(":")) {
            val parts = trimmed.split(":")
            val port = parts.last().toIntOrNull() ?: 25565
            val ip = parts.dropLast(1).joinToString(":")
            return ip to port
        }
        return trimmed to 25565
    }
}

class InstanceViewModelFactory : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return InstanceViewModel() as T
    }
}



