package com.afklauncher.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.afklauncher.AFKLauncherApp
import com.afklauncher.data.db.InstanceEntity
import com.afklauncher.protocol.ConnectionStatus
import com.afklauncher.protocol.SessionState
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class InstanceWithStatus(
    val instance: InstanceEntity,
    val sessionState: SessionState?
)

class HomeViewModel : ViewModel() {
    private val app = AFKLauncherApp.instance
    private val instanceRepository = app.instanceRepository
    private val accountRepository = app.accountRepository
    private val sessionManager = app.sessionManager

    val instances = instanceRepository.getAllInstances()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val accounts = accountRepository.getAllAccounts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sessions = sessionManager.sessions

    val instancesWithStatus: StateFlow<List<InstanceWithStatus>> = combine(
        instances,
        sessions
    ) { instanceList, sessionList ->
        instanceList.map { instance ->
            InstanceWithStatus(
                instance = instance,
                sessionState = sessionList.find { it.instanceId == instance.id }
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun startSession(instanceId: Long) {
        sessionManager.startSession(instanceId)
    }

    fun stopSession(instanceId: Long) {
        sessionManager.stopSession(instanceId)
    }

    fun deleteInstance(instance: InstanceEntity) {
        viewModelScope.launch {
            sessionManager.stopSession(instance.id)
            instanceRepository.deleteInstance(instance)
        }
    }
}

class HomeViewModelFactory : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return HomeViewModel() as T
    }
}



