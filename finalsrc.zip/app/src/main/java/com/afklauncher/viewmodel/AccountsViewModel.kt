package com.afklauncher.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.afklauncher.AFKLauncherApp
import com.afklauncher.auth.AuthState
import com.afklauncher.auth.DeviceCodeResponse
import com.afklauncher.auth.MicrosoftAuthService
import com.afklauncher.data.db.AccountEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AccountsViewModel : ViewModel() {
    private val app = AFKLauncherApp.instance
    private val accountRepository = app.accountRepository
    private val authService = MicrosoftAuthService(app)

    val accounts = accountRepository.getAllAccounts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _authState = MutableStateFlow(AuthState())
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    fun startLogin() {
        viewModelScope.launch {
            try {
                _authState.value = AuthState(isAuthenticating = true)
                val deviceCode = authService.startDeviceCodeFlow()
                _authState.value = AuthState(isAuthenticating = true, deviceCode = deviceCode)

                val result = authService.pollForToken(deviceCode)
                accountRepository.upsertAccount(
                    AccountEntity(
                        username = result.username,
                        uuid = result.uuid,
                        accessToken = result.accessToken,
                        refreshToken = result.refreshToken,
                        authDataJson = result.authDataJson
                    )
                )
                _authState.value = AuthState()
            } catch (e: Exception) {
                _authState.value = AuthState(error = e.message ?: "Authentication failed")
            }
        }
    }

    fun clearAuthError() {
        _authState.value = AuthState()
    }

    fun deleteAccount(account: AccountEntity) {
        viewModelScope.launch {
            accountRepository.deleteAccount(account)
        }
    }
}

class AccountsViewModelFactory : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return AccountsViewModel() as T
    }
}



