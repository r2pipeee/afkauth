package com.afklauncher.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.afklauncher.AFKLauncherApp
import com.afklauncher.data.db.InstanceEntity
import com.afklauncher.protocol.MovementInput
import com.afklauncher.protocol.SessionState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SessionViewModel(private val instanceId: Long) : ViewModel() {
    private val app = AFKLauncherApp.instance
    private val sessionManager = app.sessionManager
    private val instanceRepository = app.instanceRepository

    val instance = instanceRepository.getAllInstances()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sessionState: StateFlow<SessionState?> = sessionManager.sessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        .let { sessionsFlow ->
            MutableStateFlow<SessionState?>(null).also { state ->
                viewModelScope.launch {
                    sessionsFlow.collect { sessions ->
                        state.value = sessions.find { it.instanceId == instanceId }
                    }
                }
            }
        }

    private val _movementInput = MutableStateFlow(MovementInput())
    val movementInput: StateFlow<MovementInput> = _movementInput.asStateFlow()

    fun sendChat(message: String) {
        sessionManager.sendChat(instanceId, message)
    }

    fun updateMovement(input: MovementInput) {
        _movementInput.value = input
        sessionManager.updateMovement(instanceId, input)
    }

    fun jump() {
        sessionManager.jump(instanceId)
    }

    fun stopSession() {
        sessionManager.stopSession(instanceId)
    }

    fun updateInstanceSettings(instance: InstanceEntity) {
        viewModelScope.launch {
            instanceRepository.updateInstance(instance)
        }
    }
}

class SessionViewModelFactory(private val instanceId: Long) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return SessionViewModel(instanceId) as T
    }
}



