package com.afklauncher.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.afklauncher.ui.screens.AccountsScreen
import com.afklauncher.ui.screens.CreateInstanceScreen
import com.afklauncher.ui.screens.HomeScreen
import com.afklauncher.ui.screens.SessionScreen

object Routes {
    const val HOME = "home"
    const val ACCOUNTS = "accounts"
    const val CREATE_INSTANCE = "create_instance"
    const val SESSION = "session/{instanceId}"

    fun session(instanceId: Long) = "session/$instanceId"
}

@Composable
fun AFKNavGraph() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                onNavigateToAccounts = { navController.navigate(Routes.ACCOUNTS) },
                onNavigateToCreateInstance = { navController.navigate(Routes.CREATE_INSTANCE) },
                onNavigateToSession = { instanceId ->
                    navController.navigate(Routes.session(instanceId))
                }
            )
        }

        composable(Routes.ACCOUNTS) {
            AccountsScreen(onNavigateBack = { navController.popBackStack() })
        }

        composable(Routes.CREATE_INSTANCE) {
            CreateInstanceScreen(
                onNavigateBack = { navController.popBackStack() },
                onCreated = { navController.popBackStack() }
            )
        }

        composable(
            route = Routes.SESSION,
            arguments = listOf(navArgument("instanceId") { type = NavType.LongType })
        ) { backStackEntry ->
            val instanceId = backStackEntry.arguments?.getLong("instanceId") ?: return@composable
            SessionScreen(
                instanceId = instanceId,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}



