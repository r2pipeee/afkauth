package com.afklauncher.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.afklauncher.protocol.PlayerState
import com.afklauncher.ui.theme.ArmorBlue
import com.afklauncher.ui.theme.HealthRed
import com.afklauncher.ui.theme.HungerGold
import com.afklauncher.ui.theme.XPGreen

@Composable
fun PlayerHud(
    playerState: PlayerState,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StatBar(
            label = "Health",
            value = playerState.health,
            max = playerState.maxHealth,
            display = "❤".repeat((playerState.health / 2).toInt().coerceAtMost(10)),
            color = HealthRed,
            text = "${playerState.health.toInt()}/${playerState.maxHealth.toInt()}"
        )

        StatBar(
            label = "Hunger",
            value = playerState.hunger.toFloat(),
            max = 20f,
            display = "🍗".repeat((playerState.hunger / 2).coerceAtMost(10)),
            color = HungerGold,
            text = "${playerState.hunger}/20"
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "🛡 Armor: ${playerState.armor}",
                style = MaterialTheme.typography.bodyMedium,
                color = ArmorBlue
            )
            Text(
                text = "Ping: ${playerState.ping}ms",
                style = MaterialTheme.typography.bodyMedium
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Text(
                text = "Level ${playerState.xpLevel}",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = XPGreen
            )
            LinearProgressIndicator(
                progress = { playerState.xpProgress.coerceIn(0f, 1f) },
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 8.dp),
                color = XPGreen
            )
        }

        Column {
            Text(
                text = "X: ${"%.1f".format(playerState.x)}",
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                text = "Y: ${"%.1f".format(playerState.y)}",
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                text = "Z: ${"%.1f".format(playerState.z)}",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun StatBar(
    label: String,
    value: Float,
    max: Float,
    display: String,
    color: androidx.compose.ui.graphics.Color,
    text: String
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, style = MaterialTheme.typography.labelMedium)
            Text(text = text, style = MaterialTheme.typography.labelMedium)
        }
        Text(text = display, style = MaterialTheme.typography.bodyLarge)
        LinearProgressIndicator(
            progress = { (value / max).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth(),
            color = color
        )
    }
}



