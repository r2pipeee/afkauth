package com.afklauncher.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.afklauncher.AFKLauncherApp
import com.afklauncher.protocol.ConnectionStatus
import com.afklauncher.protocol.PlayerState
import com.afklauncher.ui.components.ChatPanel
import com.afklauncher.ui.components.InventoryView
import com.afklauncher.ui.components.MinimapView
import com.afklauncher.ui.components.MovementControls
import com.afklauncher.ui.components.PlayerHud
import com.afklauncher.ui.theme.StatusConnecting
import com.afklauncher.ui.theme.StatusError
import com.afklauncher.ui.theme.StatusOffline
import com.afklauncher.ui.theme.StatusOnline
import com.afklauncher.viewmodel.SessionViewModel
import com.afklauncher.viewmodel.SessionViewModelFactory
import kotlinx.coroutines.flow.map

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SessionScreen(
    instanceId: Long,
    onNavigateBack: () -> Unit,
    viewModel: SessionViewModel = viewModel(factory = SessionViewModelFactory(instanceId))
) {
    val instances by viewModel.instance.collectAsState()
    val instance = instances.find { it.id == instanceId }
    val sessionState by AFKLauncherApp.instance.sessionManager.sessions
        .map { sessions -> sessions.find { it.instanceId == instanceId } }
        .collectAsState(initial = null)
    val movementInput by viewModel.movementInput.collectAsState()
    val showTimestamps by AFKLauncherApp.instance.preferences.showChatTimestamps.collectAsState(initial = true)

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("HUD", "Chat", "Move", "Inventory", "Map")

    val playerState = sessionState?.playerState ?: PlayerState()
    val status = sessionState?.status ?: ConnectionStatus.OFFLINE
    val statusColor = when (status) {
        ConnectionStatus.ONLINE -> StatusOnline
        ConnectionStatus.CONNECTING, ConnectionStatus.RECONNECTING -> StatusConnecting
        ConnectionStatus.ERROR -> StatusError
        ConnectionStatus.OFFLINE -> StatusOffline
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = instance?.name ?: "Session",
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = status.name,
                            style = MaterialTheme.typography.bodySmall,
                            color = statusColor
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            TabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title) }
                    )
                }
            }

            when (selectedTab) {
                0 -> PlayerHud(
                    playerState = playerState,
                    modifier = Modifier
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                )
                1 -> ChatPanel(
                    messages = sessionState?.chatMessages ?: emptyList(),
                    showTimestamps = showTimestamps,
                    onSendMessage = viewModel::sendChat,
                    modifier = Modifier.fillMaxSize()
                )
                2 -> MovementControls(
                    input = movementInput,
                    onInputChange = viewModel::updateMovement,
                    onJump = viewModel::jump,
                    modifier = Modifier.padding(16.dp)
                )
                3 -> InventoryView(
                    inventory = sessionState?.inventory ?: emptyList(),
                    modifier = Modifier.padding(16.dp)
                )
                4 -> MinimapView(
                    playerState = playerState,
                    nearbyBlocks = sessionState?.nearbyBlocks ?: emptyList(),
                    modifier = Modifier.padding(16.dp)
                )
            }
        }
    }
}



