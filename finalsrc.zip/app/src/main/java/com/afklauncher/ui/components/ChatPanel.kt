package com.afklauncher.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.afklauncher.protocol.ChatMessage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatPanel(
    messages: List<ChatMessage>,
    showTimestamps: Boolean,
    onSendMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var messageText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    ColumnWithChat(
        messages = messages,
        showTimestamps = showTimestamps,
        messageText = messageText,
        onMessageChange = { messageText = it },
        onSend = {
            if (messageText.isNotBlank()) {
                onSendMessage(messageText.trim())
                messageText = ""
            }
        },
        listState = listState,
        modifier = modifier
    )
}

@Composable
private fun ColumnWithChat(
    messages: List<ChatMessage>,
    showTimestamps: Boolean,
    messageText: String,
    onMessageChange: (String) -> Unit,
    onSend: () -> Unit,
    listState: androidx.compose.foundation.lazy.LazyListState,
    modifier: Modifier = Modifier
) {
    androidx.compose.foundation.layout.Column(modifier = modifier) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(messages) { message ->
                ChatMessageItem(message, showTimestamps)
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = messageText,
                onValueChange = onMessageChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Type message...") },
                singleLine = true
            )
            TextButton(onClick = onSend) {
                Text("SEND")
            }
        }
    }
}

@Composable
private fun ChatMessageItem(message: ChatMessage, showTimestamps: Boolean) {
    val prefix = if (message.isSystem) "[Server]" else "[${message.sender}]"
    val timeFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

    Text(
        text = buildString {
            if (showTimestamps) {
                append("[${timeFormat.format(Date(message.timestamp))}] ")
            }
            append("$prefix ${message.content}")
        },
        style = MaterialTheme.typography.bodySmall,
        color = if (message.isSystem) {
            MaterialTheme.colorScheme.onSurfaceVariant
        } else {
            MaterialTheme.colorScheme.onSurface
        }
    )
}



