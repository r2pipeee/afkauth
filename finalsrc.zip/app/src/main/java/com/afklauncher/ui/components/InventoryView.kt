package com.afklauncher.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.afklauncher.protocol.InventorySlot

@Composable
fun InventoryView(
    inventory: List<InventorySlot>,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "Inventory",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )

            if (inventory.isEmpty()) {
                Text(
                    text = "No items loaded",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(inventory) { slot ->
                        RowItem(slot)
                    }
                }
            }
        }
    }
}

@Composable
private fun RowItem(slot: InventorySlot) {
    val displayName = slot.itemName
        .substringAfterLast(":")
        .replace("_", " ")
        .replaceFirstChar { it.uppercase() }

    Text(
        text = buildString {
            append("Slot ${slot.slot + 1}: ")
            append(displayName)
            if (slot.count > 1) append(" x${slot.count}")
        },
        style = MaterialTheme.typography.bodySmall
    )
}



