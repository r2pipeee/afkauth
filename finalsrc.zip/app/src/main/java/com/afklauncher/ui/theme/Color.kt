package com.afklauncher.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF0D1117)
val DarkSurface = Color(0xFF161B22)
val DarkSurfaceVariant = Color(0xFF21262D)
val DarkPrimary = Color(0xFF3FB950)
val DarkPrimaryContainer = Color(0xFF1B4332)
val DarkSecondary = Color(0xFF58A6FF)
val DarkOnBackground = Color(0xFFE6EDF3)
val DarkOnSurface = Color(0xFFC9D1D9)
val DarkOnSurfaceVariant = Color(0xFF8B949E)
val StatusOnline = Color(0xFF3FB950)
val StatusOffline = Color(0xFF8B949E)
val StatusConnecting = Color(0xFFD29922)
val StatusError = Color(0xFFF85149)
val HealthRed = Color(0xFFE74C3C)
val HungerGold = Color(0xFFF39C12)
val ArmorBlue = Color(0xFF3498DB)
val XPGreen = Color(0xFF80FF00)



