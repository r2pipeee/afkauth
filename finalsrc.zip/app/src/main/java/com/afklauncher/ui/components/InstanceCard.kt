package com.afklauncher.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.afklauncher.data.db.AccountEntity
import com.afklauncher.protocol.ConnectionStatus
import com.afklauncher.protocol.MinecraftVersions
import com.afklauncher.ui.theme.StatusConnecting
import com.afklauncher.ui.theme.StatusError
import com.afklauncher.ui.theme.StatusOffline
import com.afklauncher.ui.theme.StatusOnline
import com.afklauncher.viewmodel.InstanceWithStatus

@Composable
fun InstanceCard(
    item: InstanceWithStatus,
    account: AccountEntity?,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val status = item.sessionState?.status ?: ConnectionStatus.OFFLINE
    val playerState = item.sessionState?.playerState
    val statusColor = when (status) {
        ConnectionStatus.ONLINE -> StatusOnline
        ConnectionStatus.CONNECTING, ConnectionStatus.RECONNECTING -> StatusConnecting
        ConnectionStatus.ERROR -> StatusError
        ConnectionStatus.OFFLINE -> StatusOffline
    }

    Card(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.instance.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${item.instance.serverIP}:${item.instance.serverPort}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = {
                    if (status == ConnectionStatus.ONLINE ||
                        status == ConnectionStatus.CONNECTING ||
                        status == ConnectionStatus.RECONNECTING
                    ) {
                        onStop()
                    } else {
                        onStart()
                    }
                }) {
                    Icon(
                        imageVector = if (status == ConnectionStatus.ONLINE ||
                            status == ConnectionStatus.CONNECTING
                        ) {
                            Icons.Default.Stop
                        } else {
                            Icons.Default.PlayArrow
                        },
                        contentDescription = "Toggle session",
                        tint = statusColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row {
                Text(
                    text = "Account: ",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = account?.username ?: "None",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Row {
                Text(
                    text = "Status: ",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = status.name,
                    style = MaterialTheme.typography.bodySmall,
                    color = statusColor,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Row {
                Text(
                    text = "Version: ",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                val versionSupported = MinecraftVersions.isSupportedByCurrentBuild(item.instance.version)
                Text(
                    text = if (versionSupported) {
                        item.instance.version
                    } else {
                        "${item.instance.version} (unsupported by this build)"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (versionSupported) {
                        MaterialTheme.colorScheme.onSurface
                    } else {
                        StatusError
                    }
                )
            }

            if (status == ConnectionStatus.ONLINE && playerState != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "❤ ${playerState.health.toInt()}/${playerState.maxHealth.toInt()}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "🍗 ${playerState.hunger}/20",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "Ping: ${playerState.ping}ms",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}



