package com.afklauncher.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenu
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.afklauncher.protocol.MinecraftVersions
import com.afklauncher.viewmodel.InstanceViewModel
import com.afklauncher.viewmodel.InstanceViewModelFactory

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateInstanceScreen(
    onNavigateBack: () -> Unit,
    onCreated: () -> Unit,
    viewModel: InstanceViewModel = viewModel(factory = InstanceViewModelFactory())
) {
    val accounts by viewModel.accounts.collectAsState()

    var name by remember { mutableStateOf("") }
    var serverAddress by remember { mutableStateOf("") }
    var selectedAccountId by remember { mutableStateOf<Long?>(null) }
    var accountExpanded by remember { mutableStateOf(false) }
    var selectedVersion by remember { mutableStateOf(MinecraftVersions.defaultVersion) }
    var versionExpanded by remember { mutableStateOf(false) }
    var autoReconnect by remember { mutableStateOf(true) }
    var autoJump by remember { mutableStateOf(false) }
    var jumpInterval by remember { mutableIntStateOf(30) }
    var autoRotate by remember { mutableStateOf(false) }
    var randomMovement by remember { mutableStateOf(false) }

    val selectedAccountName = accounts.find { it.id == selectedAccountId }?.username ?: "Select account"
    val versionSupported = MinecraftVersions.isSupportedByCurrentBuild(selectedVersion)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Create Instance") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Instance Name") },
                placeholder = { Text("Skyblock Farm") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = serverAddress,
                onValueChange = { serverAddress = it },
                label = { Text("Server Address") },
                placeholder = { Text("play.server.com:25565") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            ExposedDropdownMenuBox(
                expanded = accountExpanded,
                onExpandedChange = { accountExpanded = it }
            ) {
                OutlinedTextField(
                    value = selectedAccountName,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Choose Account") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = accountExpanded) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                )
                ExposedDropdownMenu(
                    expanded = accountExpanded,
                    onDismissRequest = { accountExpanded = false }
                ) {
                    if (accounts.isEmpty()) {
                        DropdownMenuItem(
                            text = { Text("No accounts yet - add one first") },
                            onClick = { accountExpanded = false },
                            enabled = false
                        )
                    }
                    accounts.forEach { account ->
                        DropdownMenuItem(
                            text = { Text(account.username) },
                            onClick = {
                                selectedAccountId = account.id
                                accountExpanded = false
                            }
                        )
                    }
                }
            }

            ExposedDropdownMenuBox(
                expanded = versionExpanded,
                onExpandedChange = { versionExpanded = it }
            ) {
                OutlinedTextField(
                    value = selectedVersion,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Minecraft Version") },
                    supportingText = {
                        Text(
                            if (versionSupported) {
                                "Supported by this build (MCProtocolLib ${MinecraftVersions.ACTIVE_PROTOCOL_LIB_ARTIFACT})"
                            } else {
                                "Not supported by this build yet - see warning below"
                            }
                        )
                    },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = versionExpanded) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                )
                ExposedDropdownMenu(
                    expanded = versionExpanded,
                    onDismissRequest = { versionExpanded = false }
                ) {
                    MinecraftVersions.ALL.forEach { entry ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    if (entry.isSupportedByCurrentBuild) {
                                        "${entry.minecraftVersion}  ·  Supported"
                                    } else {
                                        "${entry.minecraftVersion}  ·  Requires library update"
                                    }
                                )
                            },
                            onClick = {
                                selectedVersion = entry.minecraftVersion
                                versionExpanded = false
                            }
                        )
                    }
                }
            }

            if (!versionSupported) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    )
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "This build can only connect to Minecraft ${MinecraftVersions.defaultVersion} " +
                                "right now (MCProtocolLib ${MinecraftVersions.ACTIVE_PROTOCOL_LIB_ARTIFACT}).",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Text(
                            text = "You can still create this instance to label which version its server " +
                                "runs, but it won't be able to connect until the app is updated to a " +
                                "MCProtocolLib build for $selectedVersion.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }

            Text(
                text = "AFK Settings",
                style = MaterialTheme.typography.titleMedium
            )

            SettingSwitch("Auto Reconnect", autoReconnect) { autoReconnect = it }
            SettingSwitch("Auto Jump", autoJump) { autoJump = it }
            SettingSwitch("Auto Rotate", autoRotate) { autoRotate = it }
            SettingSwitch("Random Movement", randomMovement) { randomMovement = it }

            OutlinedTextField(
                value = jumpInterval.toString(),
                onValueChange = { jumpInterval = it.toIntOrNull() ?: 30 },
                label = { Text("Jump Interval (seconds)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Button(
                onClick = {
                    if (name.isNotBlank() && serverAddress.isNotBlank()) {
                        viewModel.createInstance(
                            name = name,
                            serverAddress = serverAddress,
                            accountId = selectedAccountId,
                            version = selectedVersion,
                            autoReconnect = autoReconnect,
                            autoJump = autoJump,
                            jumpInterval = jumpInterval,
                            autoRotate = autoRotate,
                            randomMovement = randomMovement
                        )
                        onCreated()
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = name.isNotBlank() && serverAddress.isNotBlank()
            ) {
                Text("Create Instance")
            }
        }
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    androidx.compose.foundation.layout.Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        Text(text = label)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
