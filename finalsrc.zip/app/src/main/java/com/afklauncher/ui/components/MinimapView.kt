package com.afklauncher.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.afklauncher.protocol.ChunkBlock
import com.afklauncher.protocol.PlayerState
import com.afklauncher.ui.theme.DarkPrimary
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun MinimapView(
    playerState: PlayerState,
    nearbyBlocks: List<ChunkBlock>,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Text(
            text = "Minimap",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(12.dp)
        )

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .padding(12.dp)
        ) {
            val centerX = size.width / 2
            val centerY = size.height / 2
            val scale = 2f

            drawRect(
                color = Color(0xFF1A3A1A),
                size = size
            )

            nearbyBlocks.forEach { block ->
                val relX = ((block.x - playerState.x) * scale + centerX).toFloat()
                val relZ = ((block.z - playerState.z) * scale + centerY).toFloat()
                if (relX in 0f..size.width && relZ in 0f..size.height) {
                    drawRect(
                        color = Color(0xFF4A6741),
                        topLeft = Offset(relX - 2, relZ - 2),
                        size = Size(4f, 4f)
                    )
                }
            }

            drawCircle(
                color = DarkPrimary,
                radius = 6f,
                center = Offset(centerX, centerY)
            )

            val yawRad = Math.toRadians(playerState.yaw.toDouble())
            val dirX = centerX - sin(yawRad).toFloat() * 14f
            val dirY = centerY + cos(yawRad).toFloat() * 14f
            drawLine(
                color = Color.White,
                start = Offset(centerX, centerY),
                end = Offset(dirX, dirY),
                strokeWidth = 2f
            )

            drawCircle(
                color = Color.White,
                radius = 6f,
                center = Offset(centerX, centerY),
                style = Stroke(width = 1.5f)
            )
        }
    }
}



