package com.afklauncher.ui.components

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.afklauncher.protocol.MovementInput
import com.afklauncher.ui.theme.DarkPrimary

@Composable
fun MovementControls(
    input: MovementInput,
    onInputChange: (MovementInput) -> Unit,
    onJump: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        MovementButton(
            label = "W",
            active = input.forward,
            onPress = { pressed ->
                onInputChange(input.copy(forward = pressed))
            }
        )

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            MovementButton(
                label = "A",
                active = input.left,
                onPress = { pressed ->
                    onInputChange(input.copy(left = pressed))
                }
            )
            MovementButton(
                label = "S",
                active = input.backward,
                onPress = { pressed ->
                    onInputChange(input.copy(backward = pressed))
                }
            )
            MovementButton(
                label = "D",
                active = input.right,
                onPress = { pressed ->
                    onInputChange(input.copy(right = pressed))
                }
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ToggleButton(
                label = "Jump",
                active = input.jump,
                onClick = {
                    onInputChange(input.copy(jump = !input.jump))
                    onJump()
                },
                modifier = Modifier.weight(1f)
            )
            ToggleButton(
                label = "Sneak",
                active = input.sneak,
                onClick = { onInputChange(input.copy(sneak = !input.sneak)) },
                modifier = Modifier.weight(1f)
            )
            ToggleButton(
                label = "Sprint",
                active = input.sprint,
                onClick = { onInputChange(input.copy(sprint = !input.sprint)) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun MovementButton(
    label: String,
    active: Boolean,
    onPress: (Boolean) -> Unit
) {
    Box(
        modifier = Modifier
            .size(56.dp)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        onPress(true)
                        tryAwaitRelease()
                        onPress(false)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Button(
            onClick = {},
            enabled = false,
            colors = ButtonDefaults.buttonColors(
                disabledContainerColor = if (active) DarkPrimary else MaterialTheme.colorScheme.surfaceVariant,
                disabledContentColor = MaterialTheme.colorScheme.onSurface
            ),
            modifier = Modifier.size(56.dp)
        ) {
            Text(text = label, style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
private fun ToggleButton(
    label: String,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        modifier = modifier,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (active) DarkPrimary else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Text(text = label)
    }
}



