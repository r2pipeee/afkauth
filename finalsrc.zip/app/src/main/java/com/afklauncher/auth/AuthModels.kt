package com.afklauncher.auth

data class DeviceCodeResponse(
    val userCode: String,
    val deviceCode: String,
    val verificationUri: String,
    val expiresIn: Int,
    val interval: Int,
    val message: String
) {
    val directVerificationUri: String
        get() = "$verificationUri?otc=$userCode"
}

data class MinecraftProfile(
    val id: String,
    val name: String
)

data class AuthResult(
    val username: String,
    val uuid: String,
    val accessToken: String,
    val refreshToken: String,
    val authDataJson: String
)

data class AuthState(
    val isAuthenticating: Boolean = false,
    val deviceCode: DeviceCodeResponse? = null,
    val error: String? = null
)



