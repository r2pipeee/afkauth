package com.afklauncher.auth

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

class MicrosoftAuthService(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val gson = Gson()
    private val jsonMediaType = "application/json".toMediaType()
    private val formMediaType = "application/x-www-form-urlencoded".toMediaType()

    companion object {
        private const val CLIENT_ID = "00000000402b5328"
        private const val SCOPE = "XboxLive.signin offline_access"
        private const val DEVICE_CODE_URL =
            "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode"
        private const val TOKEN_URL =
            "https://login.microsoftonline.com/consumers/oauth2/v2.0/token"
        private const val XBL_AUTH_URL = "https://user.auth.xboxlive.com/user/authenticate"
        private const val XSTS_AUTH_URL = "https://xsts.auth.xboxlive.com/xsts/authorize"
        private const val MC_AUTH_URL =
            "https://api.minecraftservices.com/authentication/login_with_xbox"
        private const val MC_PROFILE_URL = "https://api.minecraftservices.com/minecraft/profile"
    }

    suspend fun startDeviceCodeFlow(): DeviceCodeResponse = withContext(Dispatchers.IO) {
        val body = "client_id=$CLIENT_ID&scope=${SCOPE.replace(" ", "+")}"
        val request = Request.Builder()
            .url(DEVICE_CODE_URL)
            .post(body.toRequestBody(formMediaType))
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string()
            ?: throw AuthException("Empty device code response")

        if (!response.isSuccessful) {
            throw AuthException("Device code request failed: $responseBody")
        }

        val json = JsonParser.parseString(responseBody).asJsonObject
        DeviceCodeResponse(
            userCode = json.get("user_code").asString,
            deviceCode = json.get("device_code").asString,
            verificationUri = json.get("verification_uri").asString,
            expiresIn = json.get("expires_in").asInt,
            interval = json.get("interval").asInt,
            message = json.get("message").asString
        )
    }

    suspend fun pollForToken(deviceCode: DeviceCodeResponse): AuthResult =
        withContext(Dispatchers.IO) {
            val startTime = System.currentTimeMillis()
            val timeoutMs = deviceCode.expiresIn * 1000L
            var intervalMs = deviceCode.interval * 1000L

            while (System.currentTimeMillis() - startTime < timeoutMs) {
                delay(intervalMs)

                val body = buildString {
                    append("grant_type=urn:ietf:params:oauth:grant-type:device_code")
                    append("&client_id=$CLIENT_ID")
                    append("&device_code=${deviceCode.deviceCode}")
                }

                val request = Request.Builder()
                    .url(TOKEN_URL)
                    .post(body.toRequestBody(formMediaType))
                    .build()

                val response = client.newCall(request).execute()
                val responseBody = response.body?.string()
                    ?: throw AuthException("Empty token response")

                val json = JsonParser.parseString(responseBody).asJsonObject

                if (response.isSuccessful) {
                    val accessToken = json.get("access_token").asString
                    val refreshToken = json.get("refresh_token").asString
                    return@withContext authenticateWithMinecraft(accessToken, refreshToken)
                }

                val error = json.get("error")?.asString
                if (error == "authorization_pending") continue
                if (error == "slow_down") {
                    intervalMs += 5000
                    continue
                }

                throw AuthException("Token polling failed: $responseBody")
            }

            throw AuthException("Authentication timed out")
        }

    suspend fun refreshAuth(refreshToken: String): AuthResult = withContext(Dispatchers.IO) {
        val body = buildString {
            append("grant_type=refresh_token")
            append("&client_id=$CLIENT_ID")
            append("&refresh_token=$refreshToken")
            append("&scope=${SCOPE.replace(" ", "+")}")
        }

        val request = Request.Builder()
            .url(TOKEN_URL)
            .post(body.toRequestBody(formMediaType))
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string()
            ?: throw AuthException("Empty refresh response")

        if (!response.isSuccessful) {
            throw AuthException("Token refresh failed: $responseBody")
        }

        val json = JsonParser.parseString(responseBody).asJsonObject
        val accessToken = json.get("access_token").asString
        val newRefreshToken = json.get("refresh_token")?.asString ?: refreshToken
        authenticateWithMinecraft(accessToken, newRefreshToken)
    }

    private fun authenticateWithMinecraft(
        msaAccessToken: String,
        refreshToken: String
    ): AuthResult {
        val xblToken = authenticateXboxLive(msaAccessToken)
        val (xstsToken, userHash) = authorizeXsts(xblToken)
        val mcToken = loginMinecraftWithXbox(xstsToken, userHash)
        val profile = fetchMinecraftProfile(mcToken)

        val authData = JsonObject().apply {
            addProperty("refreshToken", refreshToken)
            addProperty("accessToken", mcToken)
            addProperty("uuid", profile.id)
            addProperty("username", profile.name)
        }

        return AuthResult(
            username = profile.name,
            uuid = profile.id,
            accessToken = mcToken,
            refreshToken = refreshToken,
            authDataJson = authData.toString()
        )
    }

    private fun authenticateXboxLive(msaToken: String): String {
        val payload = JsonObject().apply {
            addProperty("RelyingParty", "http://auth.xboxlive.com")
            addProperty("TokenType", "JWT")
            add("Properties", JsonObject().apply {
                addProperty("AuthMethod", "RPS")
                addProperty("SiteName", "user.auth.xboxlive.com")
                add("RpsTicket", gson.toJsonTree("d=$msaToken"))
            })
        }

        val request = Request.Builder()
            .url(XBL_AUTH_URL)
            .post(payload.toString().toRequestBody(jsonMediaType))
            .header("Content-Type", "application/json")
            .header("Accept", "application/json")
            .build()

        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: throw AuthException("Empty XBL response")
        if (!response.isSuccessful) throw AuthException("XBL auth failed: $body")

        return JsonParser.parseString(body).asJsonObject.get("Token").asString
    }

    private fun authorizeXsts(xblToken: String): Pair<String, String> {
        val payload = JsonObject().apply {
            addProperty("RelyingParty", "rp://api.minecraftservices.com/")
            addProperty("TokenType", "JWT")
            add("Properties", JsonObject().apply {
                addProperty("SandboxId", "RETAIL")
                add("UserTokens", gson.toJsonTree(listOf(xblToken)))
            })
        }

        val request = Request.Builder()
            .url(XSTS_AUTH_URL)
            .post(payload.toString().toRequestBody(jsonMediaType))
            .header("Content-Type", "application/json")
            .header("Accept", "application/json")
            .build()

        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: throw AuthException("Empty XSTS response")
        if (!response.isSuccessful) throw AuthException("XSTS auth failed: $body")

        val json = JsonParser.parseString(body).asJsonObject
        val token = json.get("Token").asString
        val userHash = json.getAsJsonObject("DisplayClaims")
            .getAsJsonArray("xui")[0].asJsonObject
            .get("uhs").asString
        return token to userHash
    }

    private fun loginMinecraftWithXbox(xstsToken: String, userHash: String): String {
        val payload = JsonObject().apply {
            addProperty("identityToken", "XBL3.0 x=$userHash;$xstsToken")
        }

        val request = Request.Builder()
            .url(MC_AUTH_URL)
            .post(payload.toString().toRequestBody(jsonMediaType))
            .header("Content-Type", "application/json")
            .header("Accept", "application/json")
            .build()

        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: throw AuthException("Empty MC auth response")
        if (!response.isSuccessful) throw AuthException("Minecraft auth failed: $body")

        return JsonParser.parseString(body).asJsonObject.get("access_token").asString
    }

    private fun fetchMinecraftProfile(accessToken: String): MinecraftProfile {
        val request = Request.Builder()
            .url(MC_PROFILE_URL)
            .header("Authorization", "Bearer $accessToken")
            .get()
            .build()

        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: throw AuthException("Empty profile response")
        if (!response.isSuccessful) throw AuthException("Profile fetch failed: $body")

        val json = JsonParser.parseString(body).asJsonObject
        return MinecraftProfile(
            id = json.get("id").asString,
            name = json.get("name").asString
        )
    }
}

class AuthException(message: String) : Exception(message)

object SecureTokenStorage {
    private const val PREFS_NAME = "secure_auth_prefs"

    fun getEncryptedPrefs(context: Context) = EncryptedSharedPreferences.create(
        context,
        PREFS_NAME,
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
}



