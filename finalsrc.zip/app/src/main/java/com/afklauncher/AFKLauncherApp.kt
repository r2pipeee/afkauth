package com.afklauncher

import android.app.Application
import com.afklauncher.data.db.AppDatabase
import com.afklauncher.data.preferences.AppPreferences
import com.afklauncher.data.repository.AccountRepository
import com.afklauncher.data.repository.InstanceRepository
import com.afklauncher.protocol.SessionManager

class AFKLauncherApp : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var preferences: AppPreferences
        private set

    lateinit var accountRepository: AccountRepository
        private set

    lateinit var instanceRepository: InstanceRepository
        private set

    lateinit var sessionManager: SessionManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = AppDatabase.create(this)
        preferences = AppPreferences(this)
        accountRepository = AccountRepository(database.accountDao())
        instanceRepository = InstanceRepository(database.instanceDao())
        sessionManager = SessionManager(this, accountRepository, instanceRepository)
    }

    companion object {
        lateinit var instance: AFKLauncherApp
            private set
    }
}



