# What changed and why

Everything below was verified against real source: MCProtocolLib cloned directly from
github.com/GeyserMC/MCProtocolLib (checked out at the exact tags in question), the math
library from github.com/CloudburstMC/math, and live resolution checks against
https://repo.opencollab.dev/maven-releases/. Nothing here is guessed.

## The version reality (read this first)
**1.21.4-1 does not exist on the Maven repo.** The GitHub tag exists, but a tag existing
is not the same as an artifact having been published - it 404s on both
`maven-releases` and `maven-snapshots`, which is exactly what your build log showed.

**The real latest MCProtocolLib release is `1.21.7-1`** (Minecraft 1.21.7), confirmed by
successfully fetching its POM from the live repo. This build now targets that.

**The library is genuinely behind current Minecraft.** As of today, Java Edition is on
26.2 "Chaos Cubed" (June 16, 2026) - Mojang switched to year-based versioning in 2026,
and the 1.21.x line ended at 1.21.11 "Mounts of Mayhem" (Dec 9, 2025) before jumping to
26.1 "Tiny Takeover" (Mar 24, 2026). MCProtocolLib hasn't shipped a release since
1.21.7-1, so **this app cannot connect to any server running 1.21.8 or newer, including
all 26.x servers.** There's no code fix for this - it needs a new MCProtocolLib release,
which only GeyserMC can publish. `MinecraftVersions.kt` and the create-instance picker
now reflect this ceiling clearly instead of silently failing to connect.

## MCProtocolLib 1.21.7-1 API changes (vs. the 1.21.4-1 this was built against last round)
Re-verified every packet/class this app touches, one at a time, against the real
1.21.7-1 source:

- **`TcpClientSession` was removed entirely** (gone as of 1.21.5-1). Sessions are now
  built via `ClientNetworkSessionFactory.factory().setAddress(host, port)
  .setProtocol(protocol).create()`. This is the biggest breaking change and would have
  been a hard compile failure - confirmed by reading the official example code, not
  guessed.
- **`ServerboundChatPacket` gained a `checksum` field** (now 7 constructor args, not 6).
- **`PlayerState` (the older entity-action enum) lost `START_SNEAKING`/`STOP_SNEAKING`
  entirely** in this version - it now only has `LEAVE_BED, START_SPRINTING,
  STOP_SPRINTING, START_HORSE_JUMP, STOP_HORSE_JUMP, OPEN_VEHICLE_INVENTORY,
  START_ELYTRA_FLYING`. Sneak (and sprint) now report through a **new consolidated
  `ServerboundPlayerInputPacket`** (forward/backward/left/right/jump/shift/sprint as one
  packet, sent every tick) - this is actually the *more* correct, more vanilla-shaped
  way to do it, not a workaround. Movement now sends this every active tick alongside
  the position packet, matching real 1.21.2+ client behavior.
- Everything else - `GameProfile`/`SessionService` (unchanged package/constructor),
  `ClientboundPlayerPositionPacket`'s shape (`.position`/`.relatives`/`.id`),
  `ClientboundSetHealthPacket`/`SetExperiencePacket` fields, `ClientboundKeepAlivePacket.
  pingId`, `ServerboundClientInformationPacket`'s 9-arg constructor,
  `ServerboundAcceptTeleportationPacket`, `ServerboundPlayerLoadedPacket.INSTANCE`,
  `ServerboundClientTickEndPacket.INSTANCE`, the chunk-batch packets,
  `ClientboundSetEntityMotionPacket`, `ItemStack.id`, the adventure/math dependency
  bundles (still `adventure-text-serializer-gson` + `-json-legacy-impl`, still needs
  `math-immutable`) - all confirmed byte-for-byte identical to 1.21.4-1. Only the three
  items above actually changed.

## Velocity, gravity, and "don't get banned" - what's actually handled now
- **Gravity**: jumps arc back down (gravity 0.08, drag 0.98/tick) instead of leaving the
  player floating forever - a textbook NoFall/flight flag.
- **Server-applied velocity**: `ClientboundSetEntityMotionPacket` targeting our own
  entity (knockback, explosions, launch pads) is read and applied, decaying naturally
  through the same physics instead of being ignored or teleported.
- **Teleport confirmation**: every `ClientboundPlayerPositionPacket` gets a matching
  `ServerboundAcceptTeleportationPacket` - mandatory, or the server sees the client as
  desynced/non-vanilla.
- **Input reporting**: `ServerboundPlayerInputPacket` sent every active movement tick,
  matching what a real 1.21.2+ client actually sends (see above) instead of the
  outdated one-shot action-packet approach.
- **No duplicate keepalive acks**: confirmed via MCProtocolLib's own `ClientListener.
  java` that it already auto-replies to every keepalive
  (`AUTOMATIC_KEEP_ALIVE_MANAGEMENT`, on by default). This class only reads keepalives
  for ping display now - the old code was *also* replying, meaning the server saw two
  acks per keepalive, which no real client does.
- **`ServerboundClientTickEndPacket`** sent on ticks with nothing else to report,
  matching 1.21.2+ client behavior instead of going silent while idle.

### Known limitation (by design, not a bug)
No real block/terrain collision - there's no voxel/chunk-section data parsed, so
"ground" is approximated as the last server-confirmed Y or jump-origin Y. Correct on
flat AFK platforms/farms (the common case), not on uneven terrain. Real collision needs
full chunk section + block palette parsing - a much bigger feature than this fix.
Per-attribute gravity modifiers (a plugin changing `generic.gravity`) aren't tracked
either; the fixed 0.08 constant matches vanilla's default.

## Chunk loading - "load the server's max chunk limit"
Confirmed by reading `ClientListener.java` directly: MCProtocolLib does **not**
automatically send view-distance information. Without it, the server has no
client-declared render distance to honor. This build now sends
`ServerboundClientInformationPacket` once during the configuration phase, requesting
render distance **32** - the client-selectable maximum. The server always clamps to
`min(requested, its own configured max)`, so requesting the ceiling gets the most
chunks around the bot that server is willing to send, without needing to know that
server's actual limit in advance.

## Login bugs (from the previous pass, unchanged this round)
- Refreshed Microsoft tokens are persisted back to the account row - previously
  discarded, and since Microsoft rotates the refresh token on every use, every session
  after the first would fail to reconnect.
- Refresh failure surfaces a clear "sign-in expired" error and stops instead of
  silently reusing an old token or retrying forever with dead credentials.
- Logging into an already-added Microsoft account updates that row (matched by `uuid`,
  now a unique DB index) instead of creating a duplicate and orphaning any instances
  pointed at the original.

## Runtime-crash fix (found independently, not in any build log)
`app/build.gradle.kts` originally excluded `org.cloudburstmc.math:immutable` from the
MCProtocolLib dependency. That module is the *only* concrete `Vector3d`/`Vector3f`
implementation (the `api` module just defines interfaces + a ServiceLoader lookup).
Excluding it compiles fine and crashes at runtime the instant any packet constructs a
`Vector3d` - e.g. the first position sync after spawning.

**Update (this round):** simply removing that exclusion caused a *different* real
failure - `checkDebugDuplicateClasses`, because `org.cloudburstmc.math:immutable`'s own
`pom.xml` (github.com/CloudburstMC/math) builds it with the Maven Shade plugin and zero
relocation/exclusion config, which bundles a full unrelocated copy of every `api` class
directly into `immutable-2.0.jar`. Depending on both `api` and `immutable`
simultaneously - which is exactly what MCProtocolLib's own dependency bundle does -
means every one of those shaded classes exists twice on the classpath. That's silently
harmless on a plain JVM build (first one found wins, which is presumably why
MCProtocolLib's own example project never hits it), but a hard failure under Android's
stricter duplicate-class dexing check.

The correct fix is **excluding `org.cloudburstmc.math:api`, not `:immutable`**.
`immutable` alone is complete and self-contained - it already has everything `api`
has (shaded in) plus the actual working implementation. This resolves the duplicate-
class error *and* keeps the implementation the runtime needs, unlike the original
exclusion which only solved one of those two problems.

## Security items checked against the actual files (not all fixed - see below)
- `android:usesCleartextTraffic="true"` in `AndroidManifest.xml` was unnecessary - every
  real network call (Microsoft OAuth, Xbox Live, Minecraft session service) is HTTPS.
  The one `http://` string in the codebase is a fixed JSON payload value required by
  Xbox Live's XSTS auth protocol (`"RelyingParty": "http://auth.xboxlive.com"`), not an
  actual request URL. **Removed the flag.**
- **Not fixed, flagging clearly**: `MicrosoftAuthService.kt` defines a `SecureTokenStorage`
  object (`EncryptedSharedPreferences`-based) that is never actually called anywhere -
  tokens are stored as plain `String` columns in the Room `accounts` table. Wiring this
  up properly means moving token storage out of Room and touching
  `AccountEntity`/`AccountDao`/`AccountRepository` and the token-refresh-persistence
  flow in `MinecraftSession.connect()` that this pass just fixed. Given the size of that
  change, it's called out here rather than rushed in alongside everything else - happy
  to do it as a focused follow-up.
- One claim from the pasted audit report did **not** hold up against the actual file:
  it described a malformed `plugins {}` block at the bottom of `settings.gradle.kts`.
  That file has no such block - it's exactly `pluginManagement { ... }` +
  `dependencyResolutionManagement { ... }`, nothing after. Not changed.

## Version lock
- `app/build.gradle.kts`: `org.geysermc.mcprotocollib:protocol:1.21.7-1`.
- `MinecraftVersions.kt`: `ACTIVE_PROTOCOL_LIB_ARTIFACT = "1.21.7-1"`, table extended
  with 1.21.5/1.21.6/1.21.7 (each confirmed as its own separate MCProtocolLib release,
  not sharing an artifact the way e.g. 1.21/1.21.1 do), and the 1.21.4-1
  Maven-unavailability noted directly in the table's comments.

## Feature (from two rounds ago, still in this build)
Create Instance screen has a real Minecraft-version picker showing every version
MCProtocolLib has ever released for, which one this build actually supports, and a
clear warning if you pick a version this build can't connect to. `InstanceCard` shows
each instance's configured version too.
